# Design System Specification: The Architectural Minimalist

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Digital Architect."** In the home services sector, trust is built through precision, clarity, and structural integrity. We are moving away from the "cluttered marketplace" aesthetic toward a high-end, editorial SaaS experience that feels like a premium architectural magazine.

This system breaks the "template" look by favoring **intentional asymmetry** and **tonal layering** over rigid grids and borders. By utilizing high-contrast typography scales (Inter) and overlapping "liquid glass" surfaces, we create a sense of depth and cutting-edge sophistication. The goal is to make the user feel they are in a controlled, high-fidelity environment where every pixel has been placed with intent.

---

## 2. Colors & Surface Philosophy
Our palette is a study in subtle shifts of light and deep, authoritative shadows. We use a range of "Whites" and "Cool Grays" to define space, anchored by a deep Indigo-Charcoal primary.

### The Color Tokens
*   **Primary (Indigo-Charcoal):** `#091426` (Used for core branding and high-authority CTAs).
*   **Surface (Main Background):** `#f7f9fb` (The "canvas" of the application).
*   **Surface Container Lowest:** `#ffffff` (The "brightest" layer, used for elevated cards).
*   **Surface Container Low:** `#f2f4f6` (Subtle nesting for internal sections).
*   **Accent (Primary Container):** `#1e293b` (A softer charcoal for deep-tone utility).

### The "No-Line" Rule
Standard UI relies on `1px` borders to separate content. **This design system prohibits them.** Boundary definition must be achieved through:
1.  **Background Shifts:** Placing a `surface-container-lowest` card against a `surface` background.
2.  **Negative Space:** Using the Spacing Scale to create "gutters of light" between content blocks.

### The "Glass & Gradient" Rule
To inject "soul" into the tech, use **Liquid Glass**. Floating elements (Modals, Navigation Bars, Hovering Action Menus) should use a semi-transparent `surface-container-lowest` with a `20px` to `40px` backdrop-blur. 
*   **Signature Texture:** Main Hero CTAs should use a subtle linear gradient from `primary` (#091426) to `primary-container` (#1e293b) at a 135-degree angle to provide a metallic, premium sheen.

---

## 3. Typography
We utilize **Inter** with a focused, editorial hierarchy. To achieve the "Premium" feel, we employ **tight tracking** (-0.02em to -0.04em) on larger headers to create a dense, authoritative visual block.

*   **Display (lg/md/sm):** 3.5rem to 2.25rem. Used for hero headlines. Bold weight, -4% tracking.
*   **Headline (lg/md):** 2rem to 1.75rem. For section titles. Semi-bold, -2% tracking.
*   **Title (lg/md/sm):** 1.375rem down to 1rem. Medium weight. Used for card titles and sub-headers.
*   **Body (lg/md/sm):** 1rem to 0.75rem. Regular weight. 1.6x line height for maximum readability.
*   **Label (md/sm):** 0.75rem. All-caps with +0.05em tracking for secondary metadata or small tag UI.

---

## 4. Elevation & Depth
Hierarchy is conveyed through **Tonal Layering**, not structural lines. 

*   **The Layering Principle:** Treat the UI as stacked sheets of fine paper. 
    *   *Base:* `surface` (#f7f9fb)
    *   *Section:* `surface-container-low` (#f2f4f6)
    *   *Active Card:* `surface-container-lowest` (#ffffff)
*   **Ambient Shadows:** For floating elements, use a "Cloud Shadow."
    *   *Spec:* `0px 12px 32px rgba(25, 28, 30, 0.06)`
    *   Shadows must be tinted with the `on-surface` color to feel natural, never pure black.
*   **The "Ghost Border" Fallback:** If a container lacks contrast (e.g., White-on-White), use a `1px` stroke of `outline-variant` (#c5c6cd) at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary-container`), white text, `8px` (DEFAULT) corner radius.
*   **Secondary:** Glass effect. Semi-transparent `surface-container-highest` with backdrop blur and a Ghost Border.
*   **Tertiary:** No background. `title-sm` typography with a subtle `primary` underline on hover.

### Cards & Lists
*   **The "No-Divider" Rule:** Never use horizontal lines to separate list items. Use `12px` of vertical padding and a background shift to `surface-container-low` on hover to define the row.
*   **Radius:** Cards use `1rem` (lg) radius; inner elements like buttons or inputs use `0.5rem` (DEFAULT) to create a nested "inner-outer" harmony.

### Inputs & Fields
*   **Field Style:** Minimalist. No solid fill. Use a `surface-container-low` background with an `8px` radius. On focus, transition to a `1px` Ghost Border in `primary` and a subtle inner shadow to indicate depth.

### Signature Component: The Service Glass-Card
For home service listings, use a card with a `surface-container-lowest` base. The header image should have a "liquid glass" overlay at the bottom where the title sits, blurring the image content behind the typography to maintain high-end legibility.

---

## 6. Do's and Don'ts

### Do:
*   **Do** use asymmetrical margins. A wider left margin for a headline creates an editorial, custom-built feel.
*   **Do** use "Breathing Room." If you think there is enough white space, add 16px more.
*   **Do** use micro-interactions. A card should subtly lift (shadow deepens) and scale (1.02x) when hovered.

### Don't:
*   **Don't** use pure black (#000000) for text. Always use `on-surface` (#191c1e) to keep the "Light Theme" softness.
*   **Don't** use standard 1px gray dividers. They create "visual noise" that breaks the premium feel.
*   **Don't** use sharp 90-degree corners. Even for large sections, a "none" radius feels too industrial; stick to the `sm` to `xl` scale.